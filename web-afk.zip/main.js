const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mineflayer = require('mineflayer');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const db = new sqlite3.Database('./database.db');
const logsDir = path.join(__dirname, 'logs');

if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir);

const activeBotInstances = {};

function generateRandomName() { return 'bot_' + Math.random().toString(36).substring(2, 7); }

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, username TEXT UNIQUE, password TEXT, role TEXT DEFAULT 'user', max_bots INTEGER DEFAULT 2)`);
    db.run(`CREATE TABLE IF NOT EXISTS bots (id INTEGER PRIMARY KEY AUTOINCREMENT, owner TEXT, name TEXT, host TEXT, port INTEGER, auto_reconnect INTEGER DEFAULT 0, anti_afk INTEGER DEFAULT 0, is_running INTEGER DEFAULT 0, auto_login TEXT, log_enabled INTEGER DEFAULT 0)`);
    
    const adminPass = bcrypt.hashSync('Amalia11TY', 10);
    db.run("INSERT OR IGNORE INTO users (email, username, password, role, max_bots) VALUES ('admin@afk.ro', 'xs7david', ?, 'admin', 999999)", [adminPass]);

    db.all("SELECT * FROM bots WHERE is_running = 1", (err, rows) => {
        if (rows) rows.forEach(botData => launchBot(botData));
    });
});

app.use(express.static('public'));

app.get('/download_log/:file', (req, res) => {
    const file = req.params.file;
    // Security: Prevent path traversal
    if (file.includes('..') || file.includes('/') || file.includes('\\')) {
        return res.status(400).send('Invalid filename.');
    }
    const filePath = path.join(logsDir, file);
    if (fs.existsSync(filePath)) {
        res.download(filePath);
    } else {
        res.status(404).send("Fișier negăsit.");
    }
});

function launchBot(botData) {
    const botId = botData.id;
    if (activeBotInstances[botId]) return;

    let currentName = botData.auto_reconnect ? generateRandomName() : botData.name;

    const bot = mineflayer.createBot({
        host: botData.host,
        port: parseInt(botData.port) || 25565,
        username: currentName,
        version: false
    });

    activeBotInstances[botId] = { instance: bot, data: botData, afkLoop: null };
    db.run("UPDATE bots SET is_running = 1 WHERE id = ?", [botId]);

    bot.on('spawn', () => {
        io.emit('botStatusUpdate', { id: botId, status: 'Online', name: currentName });
        if (botData.auto_login) setTimeout(() => bot.chat(`/login ${botData.auto_login}`), 3000);
        if(botData.anti_afk === 1) {
            activeBotInstances[botId].afkLoop = setInterval(() => {
                if(bot.entity) {
                    bot.setControlState('jump', true);
                    setTimeout(() => bot.setControlState('jump', false), 500);
                    bot.swingArm('right');
                }
            }, 15000);
        }
    });

    bot.on('message', (jsonMsg) => {
        const message = jsonMsg.toString();
        const time = new Date().toLocaleTimeString('ro-RO');
        
        let formattedMsg;
        if (message.includes(' >> ') || message.includes(': ')) {
            formattedMsg = `[${time}] <span style="color:#f1c40f">${message}</span>`;
        } else {
            formattedMsg = `[${time}] <span style="color:#7f8c8d">[SERVER] ${message}</span>`;
        }
        
        io.emit(`botChat-${botId}`, formattedMsg);

        db.get("SELECT log_enabled, name, owner FROM bots WHERE id = ?", [botId], (err, row) => {
            if (row && row.log_enabled === 1) {
                const logPath = path.join(logsDir, `${row.name}_${row.owner}.txt`);
                fs.appendFileSync(logPath, `[${new Date().toLocaleString()}] ${message}\n`);
            }
        });
    });

    bot.on('end', () => {
        if(activeBotInstances[botId]?.afkLoop) clearInterval(activeBotInstances[botId].afkLoop);
        io.emit('botStatusUpdate', { id: botId, status: 'Offline' });
        if(botData.auto_reconnect && activeBotInstances[botId]) {
            setTimeout(() => { delete activeBotInstances[botId]; launchBot(botData); }, 10000);
        } else {
            delete activeBotInstances[botId];
            db.run("UPDATE bots SET is_running = 0 WHERE id = ?", [botId]);
        }
    });
}

io.on('connection', (socket) => {
    // ... (login and register handlers remain the same)

    socket.on('login', (data) => {
        db.get("SELECT * FROM users WHERE username = ?", [data.user], (err, user) => {
            if (user && (data.isHashed ? data.pass === user.password : bcrypt.compareSync(data.pass, user.password))) {
                socket.emit('loginRes', { success: true, user });
                refresh(user.username, socket);
            } else socket.emit('loginRes', { success: false });
        });
    });

    socket.on('register', (data) => {
        db.get("SELECT * FROM users WHERE username = ?", [data.user], (err, user) => {
            if (user) {
                socket.emit('registerRes', { success: false, message: 'Numele de utilizator există deja.' });
            } else {
                const hashedPassword = bcrypt.hashSync(data.pass, 10);
                db.run("INSERT INTO users (email, username, password, role, max_bots) VALUES (?, ?, ?, 'user', 2)", [data.email, data.user, hashedPassword], (err) => {
                    if (err) {
                        socket.emit('registerRes', { success: false, message: 'Eroare la înregistrare.' });
                    } else {
                        socket.emit('registerRes', { success: true });
                    }
                });
            }
        });
    });
    
    function adminRefresh() {
        db.all("SELECT * FROM bots", (err, rows) => {
            const botsWithStatus = rows.map(b => ({ ...b, is_online: activeBotInstances[b.id] ? 1 : 0 }));
            const files = fs.readdirSync(logsDir).filter(f => f.endsWith('.txt'));
            io.emit('adminData', { bots: botsWithStatus, logs: files });
        });
    }

    socket.on('adminFetchAll', adminRefresh);

    socket.on('adminDeleteLog', (filename) => {
        if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) return;
        const filePath = path.join(logsDir, filename);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
        adminRefresh(); // Refresh data for all admins
    });

    socket.on('adminGetLogContent', (filename) => {
        if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) return;
        const filePath = path.join(logsDir, filename);
        if (fs.existsSync(filePath)) {
            const content = fs.readFileSync(filePath, 'utf-8');
            socket.emit('logContentRes', { filename, content });
        }
    });

    socket.on('saveBot', (data) => {
        db.get("SELECT COUNT(*) as count FROM bots WHERE owner = ?", [data.owner], (err, row) => {
            if (err) return;
            db.get("SELECT max_bots FROM users WHERE username = ?", [data.owner], (err, user) => {
                if (err || !user) return;

                if (row.count >= user.max_bots) {
                    socket.emit('botLimitError', { message: 'Ați atins limita maximă de boți.' });
                } else {
                    db.run("INSERT INTO bots (owner, name, host, port, auto_reconnect, anti_afk, auto_login) VALUES (?,?,?,?,?,?,?)",
                    [data.owner, data.name, data.host, data.port, data.auto_reconnect, data.anti_afk, data.auto_login], (err) => {
                        if (!err) refresh(data.owner, socket);
                    });
                }
            });
        });
    });

    socket.on('adminToggleLog', (data) => {
        db.run("UPDATE bots SET log_enabled = ? WHERE id = ?", [data.val, data.id], (err) => {
            if(!err) io.emit('adminLogUpdate', { id: data.id, val: data.val });
        });
    });

    socket.on('botAction', (d) => { 
        if(activeBotInstances[d.id]) {
            activeBotInstances[d.id].instance.chat(d.msg);
            const time = new Date().toLocaleTimeString('ro-RO');
            io.emit(`botChat-${d.id}`, `[${time}] <span style="color:#ff4b2b">[YOU] ${d.msg}</span>`);
        }
    });

    socket.on('startBot', (id) => db.get("SELECT * FROM bots WHERE id = ?", [id], (err, row) => launchBot(row)));
    socket.on('stopBot', (id) => { if(activeBotInstances[id]) { activeBotInstances[id].data.auto_reconnect = 0; activeBotInstances[id].instance.quit(); }});
    socket.on('deleteBot', (id) => { db.get("SELECT owner FROM bots WHERE id = ?", [id], (err, row) => { if(activeBotInstances[id]) activeBotInstances[id].instance.quit(); db.run("DELETE FROM bots WHERE id = ?", [id], () => refresh(row.owner, socket)); })});

    function refresh(owner, s) {
        db.all("SELECT * FROM bots WHERE owner = ?", [owner], (e, rows) => {
            db.get("SELECT max_bots FROM users WHERE username = ?", [owner], (e, u) => {
                const botsWithStatus = rows.map(b => ({ ...b, is_online: activeBotInstances[b.id] ? 1 : 0 }));
                s.emit('loadSavedBots', { bots: botsWithStatus, max: u ? u.max_bots : 0 });
            });
        });
    }
});

server.listen(3000);
